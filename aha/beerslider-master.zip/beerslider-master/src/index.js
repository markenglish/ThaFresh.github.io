import './style.scss'

import Promise from 'core-js/features/promise'

import { BeerSlider as defaultExport } from './beerslider'

export default defaultExport
